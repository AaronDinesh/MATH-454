#ifndef __CONFIG_HH__
#define __CONFIG_HH__

#define DEBUG 0

#endif